import requests
import pandas as pd
import time
from datetime import datetime

HEADERS = {"User-Agent": "Mozilla/5.0 hacknu-research-bot/1.0"}

SUBREDDITS = [
    "ClaudeAI", "artificial", "MachineLearning", "ChatGPT", "LocalLLaMA",
    "technology", "singularity", "AIAssistants", "OpenAI",
    "programming", "learnprogramming", "webdev", "datascience",
    "productivity", "Entrepreneur", "startups", "SideProject",
    "VideoEditing", "StableDiffusion", "marketing", "DigitalMarketing",
    "socialmedia", "funny", "AskReddit", "NoStupidQuestions",
]

QUERIES = [
    "Claude AI", "Anthropic Claude", "claude.ai",
    "Claude vs ChatGPT", "Claude Sonnet", "Claude Opus",
    "Claude 3", "Claude 3.5", "Claude 4", "Anthropic",
    "Claude rate limit", "Claude better than GPT",
    "switched to Claude",
    "Claude slow", "Claude free", "Claude subscription",
    "best AI 2025", "best AI 2026", "Claude jailbreak",
]

# These keywords must appear in the post for it to be saved
# Prevents unrelated viral posts from slipping through
CLAUDE_KEYWORDS = ["claude", "anthropic", "claude.ai", "sonnet", "opus"]

TIME_FILTERS = ["week", "month", "year"]  


def is_claude_related(title, text):
    combined = (title + " " + text).lower()
    return any(kw in combined for kw in CLAUDE_KEYWORDS)


def paginate(url, params, max_pages=5):
    """Fetch multiple pages using Reddit's 'after' cursor."""
    all_children = []
    after = None

    for page in range(max_pages):
        if after:
            params["after"] = after

        try:
            r = requests.get(url, headers=HEADERS, params=params, timeout=15)

            if r.status_code == 429:
                print("    Rate limited — sleeping 30s...")
                time.sleep(30)
                continue

            if r.status_code != 200:
                print(f"    HTTP {r.status_code} — skipping")
                break

            data = r.json()
            children = data.get("data", {}).get("children", [])

            if not children:
                break

            all_children.extend(children)
            after = data["data"].get("after")

            if not after:
                break  # no more pages

            time.sleep(1.5)

        except Exception as e:
            print(f"    Error on page {page}: {e}")
            break

    return all_children


def child_to_dict(p, source_label):
    return {
        "platform":     "reddit",
        "id":           p["id"],
        "title":        p["title"],
        "selftext":     p.get("selftext", "")[:400],
        "score":        p["score"],
        "upvote_ratio": p.get("upvote_ratio", 0),
        "num_comments": p["num_comments"],
        "subreddit":    p["subreddit"],
        "author":       str(p.get("author", "")),
        "url":          "https://reddit.com" + p["permalink"],
        "created_utc":  datetime.utcfromtimestamp(p["created_utc"]),
        "source":       source_label,
        "virality_score": p["score"] * p.get("upvote_ratio", 1) + p["num_comments"] * 2,
    }


posts = []

# ── PHASE 1: keyword search across ALL of Reddit + multiple time windows ──
print("=" * 55)
print("PHASE 1: Global keyword search (multiple time windows)")
print("=" * 55)

for time_filter in TIME_FILTERS:
    for query in QUERIES:
        children = paginate(
            "https://www.reddit.com/search.json",
            {"q": query, "sort": "top", "limit": 100, "t": time_filter},
            max_pages=3,
        )
        added = 0
        for c in children:
            p = c["data"]
            if is_claude_related(p.get("title", ""), p.get("selftext", "")):
                posts.append(child_to_dict(p, f"search:{query}:{time_filter}"))
                added += 1

        print(f"  ✓ '{query}' [{time_filter}]: {len(children)} fetched, {added} Claude-related")
        time.sleep(2)
""""
# ── PHASE 2: subreddit-level hot/top/new ──────────────────────
print("\n" + "=" * 55)
print("PHASE 2: Subreddit hot / top / new")
print("=" * 55)

for sub in SUBREDDITS:
    for sort in ["hot", "new", "top"]:
        params = {"limit": 100}
        if sort == "top":
            params["t"] = "year"   # top posts of the last year

        children = paginate(
            f"https://www.reddit.com/r/{sub}/{sort}.json",
            params,
            max_pages=3,
        )

        added = 0
        for c in children:
            p = c["data"]
            if is_claude_related(p.get("title", ""), p.get("selftext", "")):
                posts.append(child_to_dict(p, f"r/{sub}:{sort}"))
                added += 1

        if added:
            print(f"  ✓ r/{sub}/{sort}: {added} Claude posts (of {len(children)} total)")

        time.sleep(1.5)

# ── PHASE 3: subreddit keyword search (past year) ────────────
print("\n" + "=" * 55)
print("PHASE 3: Subreddit-specific keyword search")
print("=" * 55)

TARGET_SUBS = [
    "ClaudeAI", "ChatGPT", "artificial", "LocalLLaMA",
    "MachineLearning", "technology", "OpenAI", "singularity",
]

for sub in TARGET_SUBS:
    for query in ["Claude", "Anthropic", "claude AI", "Claude Sonnet", "Claude rate limit"]:
        for tf in ["month", "year"]:
            children = paginate(
                f"https://www.reddit.com/r/{sub}/search.json",
                {"q": query, "restrict_sr": "true", "sort": "top",
                 "limit": 100, "t": tf},
                max_pages=3,
            )
            added = 0
            for c in children:
                p = c["data"]
                if is_claude_related(p.get("title", ""), p.get("selftext", "")):
                    posts.append(child_to_dict(p, f"r/{sub}:search:{query}:{tf}"))
                    added += 1

            if added:
                print(f"  ✓ r/{sub} + '{query}' [{tf}]: {added} posts")
            time.sleep(1.5)
"""
# ── SAVE ──────────────────────────────────────────────────────
df = pd.DataFrame(posts).drop_duplicates(subset="id")
df = df.sort_values("virality_score", ascending=False)
df.to_csv("reddit_data.csv", index=False)

print(f"\n{'='*55}")
print(f"✅ Done! {len(df):,} unique Claude-related posts saved to reddit_data.csv")
print(f"   Date range: {df['created_utc'].min()} → {df['created_utc'].max()}")
print(f"   Top subreddits: {df['subreddit'].value_counts().head(8).to_dict()}")
print(f"{'='*55}")